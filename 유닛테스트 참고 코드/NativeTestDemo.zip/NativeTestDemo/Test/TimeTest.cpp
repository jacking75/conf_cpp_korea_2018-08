#include "stdafx.h"
#include "CppUnitTest.h"
#include <orz/Time.h>

using namespace Microsoft::VisualStudio::CppUnitTestFramework;
using namespace orz;

namespace orzTest {

  TEST_CLASS(TimeTest) {
  public:

    TEST_METHOD(constructor) {
      Time time(1,2,3);
      Assert::AreEqual(1, time.hour());
      Assert::AreEqual(2, time.minute());
      Assert::AreEqual(3, time.second());
      Time time2(time);
      Assert::AreEqual(1, time2.hour());
      Assert::AreEqual(2, time2.minute());
      Assert::AreEqual(3, time2.second());
    }

    TEST_METHOD(copy) {
      Time src(1,2,3);
      Time time;
      time = src;
      Assert::AreEqual(1, time.hour());
      Assert::AreEqual(2, time.minute());
      Assert::AreEqual(3, time.second());
    }

    TEST_METHOD(good_time) {
      Time time;
      Assert::IsTrue(time.set( 0, 0, 0).is_valid());
      Assert::IsTrue(time.set(23,59,59).is_valid());
    }

    TEST_METHOD(bad_hour) {
      Time time;
      Assert::IsFalse(time.set(-1, 0, 0).is_valid());
      Assert::IsFalse(time.set(24, 0, 0).is_valid());
    }

    TEST_METHOD(bad_minute) {
      Time time;
      Assert::IsFalse(time.set( 0,-1, 0).is_valid());
      Assert::IsFalse(time.set( 0,60, 0).is_valid());
    }

    TEST_METHOD(bad_second) {
      Time time;
      Assert::IsFalse(time.set( 0, 0,-1).is_valid());
      Assert::IsFalse(time.set( 0, 0,60).is_valid());
    }
  };
}
