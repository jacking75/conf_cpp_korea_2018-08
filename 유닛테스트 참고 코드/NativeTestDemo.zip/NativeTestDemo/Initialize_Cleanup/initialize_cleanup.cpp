#include "stdafx.h"
#include "CppUnitTest.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace codezine
{		
	TEST_MODULE_INITIALIZE(test_module_initialize) { Logger::WriteMessage(__FUNCTION__); }
	TEST_MODULE_CLEANUP(test_module_cleanup) { Logger::WriteMessage(__FUNCTION__); }

	TEST_CLASS(Initialize_Cleanup)
	{
	public:
		TEST_CLASS_INITIALIZE(test_class_initialize) { Logger::WriteMessage(__FUNCTION__); }
		TEST_CLASS_CLEANUP(test_class_cleanup) { Logger::WriteMessage(__FUNCTION__); }
		
		TEST_METHOD_INITIALIZE(test_method_initialize) { Logger::WriteMessage(__FUNCTION__); }
		TEST_METHOD_CLEANUP(test_method_cleanup) { Logger::WriteMessage(__FUNCTION__); }
		
		TEST_METHOD(test_method_1) { Logger::WriteMessage(__FUNCTION__); }
		TEST_METHOD(test_method_2) { Logger::WriteMessage(__FUNCTION__); }
		TEST_METHOD(test_method_3) { Logger::WriteMessage(__FUNCTION__); }

	};
}