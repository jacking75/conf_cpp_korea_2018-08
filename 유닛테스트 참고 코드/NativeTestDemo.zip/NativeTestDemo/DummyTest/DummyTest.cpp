#include "stdafx.h"
#include "CppUnitTest.h"
#include <stdexcept>
#include <cmath>

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace dummy {

  double square_root(double x) {
    if ( x < 0.0 ) {
      throw std::domain_error("the arg shoul not be less than zero");
    }
    return std::sqrt(x);
  }

}

namespace dummyTest {

  TEST_CLASS(UnitTest) {
  public:

    TEST_METHOD(good_square_root) {
      Assert::AreEqual(0.0 , dummy::square_root(0.0), 0.01);
      Assert::AreEqual(1.41, dummy::square_root(2.0), 0.01);
    }

    double exception_will_be_thrown(double x) {
      if ( x > 0.0 ) x = -x;
      return dummy::square_root(x);
    }

    static double exception_will_be_thrown_static() {
      return dummy::square_root(-1.0);
    }

    TEST_METHOD(bad_square_root) {
      Assert::ExpectException<std::domain_error>([](){ dummy::square_root(-1.0);});
      Assert::ExpectException<std::domain_error>([this](){ exception_will_be_thrown(2.0);});
      Assert::ExpectException<std::domain_error>(&exception_will_be_thrown_static);
    }
  };
}